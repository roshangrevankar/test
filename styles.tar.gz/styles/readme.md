# vanderlande-styles

> Injects Vanderlande Ui Styles by overriding the Kibana css Rules

@author: Robin Sander <Robin.Sander@vanderlande.com>

---

## development

Developed for Kibana Version 6.6.1 !

See the [kibana contributing guide](https://github.com/elastic/kibana/blob/master/CONTRIBUTING.md) for instructions setting up your development environment. Once you have completed that, use the following yarn scripts.
  
  - checkout this project into a Folder "kibana-extra" next to Kibana. (see also Kibanas plugin development guide) 

  - `yarn kbn bootstrap` (ignore! `ERROR TypeError: Cannot read property 'replace' of undefined`)

    Install dependencies and crosslink Kibana and all projects/plugins.

  - `yarn start`

    Start kibana and have it include this plugin. You can pass any arguments that you would normally send to `bin/kibana`

      ```
      yarn start --elasticsearch.hosts http://localhost:9220
      ```

  - `yarn build`

    Build a distributable archive of your plugin.

  - `yarn test:browser`

    Run the browser tests in a real web browser.

  - `yarn test:server`

    Run the server tests using mocha.

For more information about any of these commands run `yarn ${task} --help`. For a full list of tasks checkout the `package.json` file, or run `yarn run`.
