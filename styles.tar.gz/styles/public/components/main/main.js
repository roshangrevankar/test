import React from 'react';
import {
  EuiPage,
  EuiPageHeader,
  EuiTitle,
  EuiPageBody,
  EuiPageContent,
  EuiPageContentHeader,
  EuiPageContentBody,
  EuiText,
  EuiCodeBlock,
  EuiSpacer
} from '@elastic/eui';

const cssCode = `.dscTable {
    .kbnDocTableCell__dataField {
        white-space: pre !important;
        border-right: 1px solid #D3DAE6 !important;
    }
    .kbn-table th, .kbn-table th, .kbnDocTable__row td {
        padding: 0px !important;
        padding-right: 10px !important;
        border: none;
        color: black !important;
        line-height: 1em !important;
        font-size: 1em !important;
        padding-bottom: 1px !important;
    }
    .eui-textNoWrap {
        border-right: none !important;
    }
    .euiButtonIcon--text {
        margin-top: -6px !important;
    }
}
`;

export class Main extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount() {
    /*
       FOR EXAMPLE PURPOSES ONLY.  There are much better ways to
       manage state and update your UI than this.
    */
    const { httpClient } = this.props;
    httpClient.get('../api/vanderlande-styles/example').then((resp) => {
      this.setState({ time: resp.data.time });
    });
  }


  render() {
    const { title } = this.props;
    return (
      <EuiPage>
        <EuiPageBody>
          <EuiPageHeader>
            <EuiTitle size="l">
              <h1>{title}</h1>
            </EuiTitle>
          </EuiPageHeader>
          <EuiPageContent>
            <EuiPageContentBody>
              <EuiText>
                <h3>A plugin to inject vanderlande styles in Kibana</h3>
                <p>The following styles are now active</p>
              </EuiText>
              <EuiCodeBlock language="css" fontSize="m" paddingSize="m" color="dark" overflowHeight={300} isCopyable>
                    {cssCode}
               </EuiCodeBlock>
            </EuiPageContentBody>
          </EuiPageContent>
        </EuiPageBody>
      </EuiPage>
    );
  }
}
