export const PLUGIN_ID = 'first';
export const PLUGIN_NAME = 'first';
