export default function (kibana) {
  return new kibana.Plugin({
    require: ['elasticsearch'],
    name: 'vanderlande_styles',
    uiExports: {
      app: {
        title: 'Vanderlande Styles',
        description: 'Injects Vanderlande Ui Styles by overriding css rules',
        main: 'plugins/vanderlande_styles/app',
      },
      hacks: [
        'plugins/vanderlande_styles/hack'
      ],
    },

    config(Joi) {
      return Joi.object({
        enabled: Joi.boolean().default(true),
      }).default();
    },
  });
}
