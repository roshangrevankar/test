import $ from 'jquery';
import 'plugins/vanderlande_styles/less/main.less';
import 'plugins/vanderlande_styles/less/discover.less';
